package com.bmh.trackchild.Tools;

public interface AppPermissionInterFace {

   void onAllPermissionGranted();
}
