package com.bmh.trackchild.UI;

import android.app.DialogFragment;

public interface ConfirmDialogInterface {
    public void onDialogPositiveClick(DialogFragment dialog);
    public void onDialogNegativeClick(DialogFragment dialog);

}
