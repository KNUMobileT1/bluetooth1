"# Track-Child" 
An app that helps parent to track his/her son within 10 meter area using Bluetooth.
When the son’s device be not reachable, the app will alarms the parent and the parent
will be able to send an SMS to his/her son’s device to get his/her location.
